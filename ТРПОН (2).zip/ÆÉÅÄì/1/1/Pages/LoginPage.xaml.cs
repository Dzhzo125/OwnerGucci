﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _1.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
        //private void Button_Click(object sender, RoutedEventArgs e)
        //{
        //    string login = "1234";
        //    string password = "1234";

        //    if (Llogin.Text == login && Ppassword.Password ==password)
        //    {
        //        MessageBox.Show("Vierno");
        //        return;
        //    }
        //    MessageBox.Show("ne vierno");
        //}
    

public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void BTEnter_Click(object sender, RoutedEventArgs e)
        {
            
                string login = "1234";
                string password = "1234";
            if (Llogin.Text == login && Ppassword.Password == password)
        }
    }
}
