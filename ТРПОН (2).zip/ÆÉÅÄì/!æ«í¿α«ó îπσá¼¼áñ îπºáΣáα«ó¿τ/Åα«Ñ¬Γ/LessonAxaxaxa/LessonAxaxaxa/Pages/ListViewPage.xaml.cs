﻿using LessonAxaxaxa.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LessonAxaxaxa.Pages
{
    /// <summary>
    /// Логика взаимодействия для ListViewPage.xaml
    /// </summary>
    public partial class ListViewPage : Page
    {
        public ListViewPage()
        {
            InitializeComponent();
            DGProducts.ItemsSource = App.Db.Products.ToList();
        }

        private void BTAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditUsersPage());
        }

        private void BTDelete_Click(object sender, RoutedEventArgs e)
        {
            var selectedProduct = (Products)DGProducts.SelectedItem;

            if (selectedProduct == null)
            {
                MessageBox.Show("Выберите товар!");
            }
            else
            {
                App.Db.Products.Remove(selectedProduct);
                App.Db.SaveChanges();
                DGProducts.ItemsSource = App.Db.Products.ToList();
            }
        }

        private void BTEdit_Click(object sender, RoutedEventArgs e)
        {
            var selectedProduct = (Products)DGProducts.SelectedItem;

            if (selectedProduct == null)
            {
                MessageBox.Show("Выберите товар!");
            }
            else
            {
                NavigationService.Navigate(new AddEditUsersPage(selectedProduct));
            }
        }
    }
}
