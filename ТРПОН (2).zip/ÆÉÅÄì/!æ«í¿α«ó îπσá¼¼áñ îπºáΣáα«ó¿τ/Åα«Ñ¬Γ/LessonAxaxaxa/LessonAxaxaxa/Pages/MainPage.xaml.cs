﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LessonAxaxaxa.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void BTProfile_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProfilePage());
        }

        private void BTMenu_Click(object sender, RoutedEventArgs e)
        {
            MenuFrame.Navigate(new MenuPage());

        }

        private void BTNet_Click(object sender, RoutedEventArgs e)
        {
            MenuFrame.Navigate(new NetPage());

        }

        private void BTPo_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("PO");
        }

        private void BTBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
