﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using LessonAxaxaxa.Models;


namespace LessonAxaxaxa.Pages
{
    public partial class AddEditUsersPage : Page
    {
        Products product;

        //Edit
        public AddEditUsersPage(Products selectedProduct)
        {
            InitializeComponent();
            CBCategories.ItemsSource = App.Db.Categories.ToList();
            CBSuppliers.ItemsSource = App.Db.Suppliers.ToList();
            product = selectedProduct;

            TBName.Text = product.ProductName;
            TBPrice.Text = product.Price.ToString();
            CBCategories.SelectedValue = product.CategoryID;
            CBSuppliers.SelectedValue = product.SupplierID;
            DPCreateDate.SelectedDate = product.CreatedDate;
        }

        //Add
        public AddEditUsersPage()
        {
            InitializeComponent();
            CBCategories.ItemsSource = App.Db.Categories.ToList();
            CBSuppliers.ItemsSource = App.Db.Suppliers.ToList();
            product = new Products();
        }

        private void BTSave_Click(object sender, RoutedEventArgs e)
        {
           if (string.IsNullOrWhiteSpace(TBName.Text) ||
               string.IsNullOrWhiteSpace(TBPrice.Text) ||
               CBCategories.SelectedItem == null ||
               CBSuppliers.SelectedItem == null ||
               DPCreateDate.SelectedDate == null)
            {
                MessageBox.Show("заполните все поля!");
                return;
            }

            product.ProductName = TBName.Text;
            product.Price = decimal.Parse(TBPrice.Text);
            product.CategoryID = (int)CBCategories.SelectedValue;
            product.SupplierID = (int)CBSuppliers.SelectedValue;
            product.CreatedDate = DateTime.Now;
            
            if (product.ProductID == 0)
            {
                App.Db.Products.Add(product);
            }
            App.Db.SaveChanges();

            MessageBox.Show("Успешно");
        }

        private void BTCansel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
